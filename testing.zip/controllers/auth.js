const mysql = require('mysql');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
var dateTime = require('node-datetime');

const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

//current date with time
var dt = dateTime.create();
var formatted = dt.format('Y-m-d H:M:S');

/*For Admin Login*/
exports.adminlogin = async (req, res) => {
    try {

        const {
            u_email,
            u_password
        } = req.body;
        if (u_email == '' || u_password == '') {
            return res.render('adminlogin', {
                message: 'Please Provide Email and password'
            });
        }

        db.query('SELECT * FROM user WHERE u_email = ?', [u_email], async (error, results) => {
            if (!results || results[0].u_pass != u_password) {
                res.status(401).render('adminlogin', {
                    message: 'Email or password is incorrect'
                });
            } else {
                const id = results[0].id;
                const token = jwt.sign({
                    id
                }, process.env.JWT_SECRET, {
                    expiresIn: process.env.JWT_EXPIRES_IN
                });


                const cookieOptions = {
                    expires: new Date(
                        Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000
                    ),
                    httpOnly: true
                }

                res.cookie('jwt', token, cookieOptions);
                res.status(200).redirect("/admindashboard");
            }
        });

    } catch (error) {
        console.log(error);
    }
}

/*For Voter Login*/
exports.login = async (req, res) => {

    try {
        const {
            u_email,
            u_password
        } = req.body;

        if (u_email == '' || u_password == '') {
            return res.render('login', {
                message: 'Please Provide Email and password'
            })
        }

        db.query('SELECT * FROM voters WHERE email = ?', [u_email], async (error, results) => {
            if (!results || !(await bcrypt.compare(u_password, results[0].password))) {
                res.status(401).render('login', {
                    message: 'Email or password is incorrect'
                });
            } else {
                const id = results[0].id;
                const token = jwt.sign({
                    id
                }, process.env.JWT_SECRET, {
                    expiresIn: process.env.JWT_EXPIRES_IN
                });

                // console.log("The Token  is: " + token);

                const cookieOptions = {
                    expires: new Date(
                        Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000
                    ),
                    httpOnly: true
                }

                res.cookie('jwt', token, cookieOptions);
                res.status(200).redirect("/voterdashboard");

            }

        });

    } catch (error) {
        console.log(error);
    }

}

/*For Voter Register*/
exports.register = (req, res) => {
    const {
        name,
        email,
        phone,
        adhar_no,
        address,
        password,
        passwordConfirmed
    } = req.body;
    db.query('SELECT email FROM voters WHERE email = ?', [email], async (error, results) => {
        if (error) {
            console.log(error);
        }

        if (results.length > 0) {
            return res.render('voterlogin', {
                message: 'That Email  is already in use'
            })
        } else if (password != passwordConfirmed) {
            return res.render('voterlogin', {
                message: 'password do not match'
            });
        }
        let hashPassword = await bcrypt.hash(password, 8);

        db.query('INSERT INTO voters SET ?', {
            name: name,
            phone: phone,
            address: address,
            email: email,
            password: hashPassword,
            adhar_no: adhar_no,
            verification_token: '',
            token_status: 0,
            creation_date: formatted
        }, (error, results) => {
            if (error) {
                console.log(error);
            } else {
                console.log(results);
                return res.render('voterlogin', {
                    message: 'Registration Successfull'
                })
            }
        });
    });

}