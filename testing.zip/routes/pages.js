const express = require("express");
const fs = require('fs');

const router  = express.Router();

router.get('/', (req, res) => {
	res.render('index');
});

router.get('/voterlogin', (req, res) => {
	res.render('voterlogin');
});

router.get('/login', (req, res) => {
	res.render('login');
});

router.get('/adminlogin', (req, res) => {
	res.render('adminlogin');
});

router.get('/admindashboard', (req,res) => {
	res.render('admindashboard');
});

router.get('/voterdashboard', (req,res) => {
	res.render('voterdashboard');
});

router.get('/addcandidate', (req, res) => {
	res.render('addcandidate');
});

router.get('/electionresult', (req, res) => {
	res.render('electionresult');
});

router.get('/logout', function (req, res) {
  res.clearCookie('connect.sid');
  res.redirect('/');
});



module.exports = router;